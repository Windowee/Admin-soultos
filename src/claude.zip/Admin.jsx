// Admin.jsx
import './Admin.css';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

// Import your admin page components
import AdminOrders from './AdminOrders'; // Create this component
import AdminPayments from './AdminPayments'; // Create this component
import AdminVerifications from './AdminVerifications'; // Import the new component

function AdminApp() {
    return (
        <Router>
            <header>
                <div className="header-navbar-container">
                    {/* Navigation Bar */}
                    <nav className="navbar">
                        <ul>
                            <li><Link to="/admin/orders">Orders</Link></li>
                            <li><Link to="/admin/payments">Payments</Link></li>
                            <li><Link to="/admin/verifications">Verifications</Link></li> {/* Add link to Verifications */}
                        </ul>
                    </nav>
                </div>
            </header>

            {/* Main Content */}
            <main>
                <Routes>
                    <Route path="/admin/orders" element={<AdminOrders />} />
                    <Route path="/admin/payments" element={<AdminPayments />} />
                    <Route path="/admin/verifications" element={<AdminVerifications />} /> {/* Add new route */}
                </Routes>
            </main>
        </Router>
    );
}

export default AdminApp;


